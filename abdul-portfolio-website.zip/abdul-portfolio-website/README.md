# Abdul Haseeb Khan — Portfolio Website

## Files
- `index.html` — the main one-page site (Home, About, Experience, Skills, Projects, Research, Achievements, Education, CV, Contact)
- `project-inflation.html` — detail page for the featured Inflation & Corporate Profitability project
- `styles.css` — all styling (single file, shared by both pages)
- `script.js` — sticky nav / mobile menu, the ticker strip, scroll animations, and the contact form

## How to view it right now
Open `index.html` directly in a browser, or from a terminal in this folder run:
```
python3 -m http.server 8080
```
then visit `http://localhost:8080`.

## How to publish it
Any static host works, for example:
- **GitHub Pages** — push this folder to a repo and enable Pages in Settings.
- **Netlify / Vercel** — drag-and-drop this folder onto their dashboard.
No build step is needed — it's plain HTML/CSS/JS.

## Placeholders to fill in before publishing
Every one of these appears with a dashed underline / dashed border on the live site so they're easy to spot. Search each file for the marker text below.

**Links**
- Download CV button (hero, and CV section) — currently `href="#"`, needs your hosted CV file link
- GitHub profile URL — appears in the hero is not present, but in Contact and in the Projects "Visit My GitHub" button, and on the project detail page
- Diminishing Musharakah project — link to the file or write-up

**Content**
- CV section: "Last updated" month/year
- Experience: a third role/organization slot is left empty for you to fill in (or delete the block if not needed)
- MeezanShip Trainee: an extra bullet point slot for more responsibilities/tools
- Decision Science project card: title + real project once documented
- Data Visualization project card: title + real project once documented
- BRICS Arts Festival: one-line description of your role or takeaway
- Certificates list: one open slot, plus "Add file / link" on every certificate row (link to an image or PDF once you have them hosted)
- Research in Progress: four placeholder rows (working paper, proposal, policy brief, thesis) — delete any you don't need
- Project detail page (Inflation & Corporate Profitability): research question wording, sample size/period, headline results, policy implications, lessons learned, and the repository link

## Notes
- No information was invented. Everything outside the placeholders reflects what you've told me (IOFS 2025, IFY 2026, FinSec Knowledge Hub, MeezanShip traineeship, coursework, etc.).
- CGPA was intentionally left off, consistent with how you've wanted your other CV materials handled.
- The contact form currently opens the visitor's email client with the message pre-filled (no backend). If you want real form submissions without that, connect a service like Formspree and swap the form's `action` accordingly — ask me and I can wire that up.
