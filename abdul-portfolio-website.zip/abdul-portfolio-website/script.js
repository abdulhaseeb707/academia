// Footer year
(function () {
  var yearEl = document.getElementById('year');
  if (yearEl) { yearEl.textContent = new Date().getFullYear(); }
})();

// Mobile nav toggle
(function () {
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  if (!navToggle || !navLinks) { return; }
  navToggle.addEventListener('click', function () {
    var open = navLinks.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  var links = navLinks.querySelectorAll('a');
  for (var i = 0; i < links.length; i++) {
    links[i].addEventListener('click', function () {
      navLinks.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  }
})();

// Ticker: the HTML already holds one pass of items (works with no JS).
// Duplicate that pass once so the CSS marquee (-50%) loops seamlessly.
(function () {
  var track = document.getElementById('tickerTrack');
  if (!track) { return; }
  track.innerHTML = track.innerHTML + track.innerHTML;
})();

// Scroll reveal
(function () {
  var revealEls = document.querySelectorAll('.reveal');
  if (!revealEls.length) { return; }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      for (var i = 0; i < entries.length; i++) {
        var entry = entries[i];
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      }
    }, { threshold: 0.15 });
    for (var j = 0; j < revealEls.length; j++) { io.observe(revealEls[j]); }
  } else {
    for (var k = 0; k < revealEls.length; k++) { revealEls[k].classList.add('is-visible'); }
  }
})();

// Contact form -> mailto fallback (no backend wired up)
(function () {
  var contactForm = document.getElementById('contactForm');
  if (!contactForm) { return; }
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = document.getElementById('cf-name').value;
    var email = document.getElementById('cf-email').value;
    var message = document.getElementById('cf-msg').value;
    var subject = encodeURIComponent('Portfolio contact from ' + name);
    var body = encodeURIComponent(message + '\n\n— ' + name + ' (' + email + ')');
    window.location.href = 'mailto:abdulhaseeb2130@gmail.com?subject=' + subject + '&body=' + body;
  });
})();
